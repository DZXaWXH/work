package com.noteworkshop.util;

import com.noteworkshop.vo.ResultVO;

public class ResultUtil {
    public static <T> ResultVO<T> ok(T data){
        return ResultVO.success(data);
    }
}
