package com.noteworkshop.service.impl;

import com.noteworkshop.entity.Result;
import com.noteworkshop.entity.User;
import com.noteworkshop.mapper.UserMapper;
import com.noteworkshop.service.UserService;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;



@Service  // ✅ 必须有这个！！
public class UserServiceImpl implements UserService {

    @Resource
    private UserMapper userMapper;

    @Override
    public User getUserById(Integer id) {
        return userMapper.selectById(id);
    }

    @Override
    public Result register(User user) {
        User existUser = userMapper.selectByUsername(user.getUsername());
        if(existUser != null){
            return Result.error("用户名已经被占用");
        }
        userMapper.insert(user);
        return Result.success(null);
    }

}
