package com.noteworkshop.service;

import com.noteworkshop.entity.Result;
import com.noteworkshop.entity.User;

public interface UserService {
    User getUserById(Integer id);
    Result register(User user);
}
