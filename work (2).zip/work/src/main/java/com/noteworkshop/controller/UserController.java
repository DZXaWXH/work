package com.noteworkshop.controller;

import com.noteworkshop.entity.User;
import com.noteworkshop.entity.Result;
import com.noteworkshop.service.UserService;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;

@RestController
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserService userService;

    @GetMapping("/{id}")
    public User getById(@PathVariable Integer id){
        return userService.getUserById(id);
    }
    @PostMapping("/register")
    public Result register(@RequestBody User user){
        return userService.register(user);
    }
}
