package com.noteworkshop;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.noteworkshop.mapper")
public class NoteWorkshopApplication {
    public static void main(String[] args) {
        SpringApplication.run(NoteWorkshopApplication.class, args);
    }
}
