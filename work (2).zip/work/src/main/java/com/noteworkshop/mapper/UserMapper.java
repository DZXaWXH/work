package com.noteworkshop.mapper;

import com.noteworkshop.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper {

    @Select("select * from `user` where id = #{id}")
    User selectById(Integer id);

    @Select("select * from `user` where username = #{username}")
    User selectByUsername(String username);

    @Insert("INSERT INTO `user`(username,password,nickname) VALUES(#{username},#{password},#{nickname})")
    int insert(User user);
}
