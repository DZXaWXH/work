package com.noteworkshop.exception;

import com.noteworkshop.vo.ResultVO;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(Exception.class)
    public ResultVO<String> handleException(Exception e){
        e.printStackTrace();
        return ResultVO.fail(e.getMessage());
    }
}
